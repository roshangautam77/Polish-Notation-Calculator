var app = angular.module('polishCalculatorApp', []);

